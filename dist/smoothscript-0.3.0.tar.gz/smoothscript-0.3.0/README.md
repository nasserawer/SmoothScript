<h1 align="center">SmoothScript</h1>

### What is SmoothScript?
It is a python library that contains a set of ready-made codes that enable you to create the most wonderful designs and animations on the terminal.

### Support
+ linux
+ termux
+ windows


### Install
Just write this code on terminal:
```shell
pip3 install smoothscript
```

___

<p align="center">
<strong>For more infrmation</strong>
</p>

<p align="center">
<a href="https://github.com/nasserawer/smoothscript/"><label style="display: block;"><strong>SmoothScript</strong></label></a>
</p>
